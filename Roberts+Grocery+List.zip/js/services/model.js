/**
 * Data models
 */
Apperyio.Entity = new Apperyio.EntityFactory({
    "Number": {
        "type": "number"
    },
    "cartList": {
        "type": "array",
        "items": {
            "type": "groceryObject"
        }
    },
    "Boolean": {
        "type": "boolean"
    },
    "groceryList": {
        "type": "array",
        "items": {
            "type": "groceryObject"
        }
    },
    "String": {
        "type": "string"
    },
    "groceryObject": {
        "type": "object",
        "properties": {
            "amount": {
                "type": "string"
            },
            "name": {
                "type": "string"
            }
        }
    }
});
Apperyio.getModel = Apperyio.Entity.get.bind(Apperyio.Entity);

/**
 * Data storage
 */
Apperyio.storage = {

    "itemName": new $a.SessionStorage("itemName", "String"),

    "numOfItem": new $a.SessionStorage("numOfItem", "Number"),

    "idOfItem": new $a.SessionStorage("idOfItem", "String"),

    "groceryList": new $a.LocalStorage("groceryList", "groceryList"),

    "groceryObject": new $a.SessionStorage("groceryObject", "groceryObject"),

    "cartList": new $a.SessionStorage("cartList", "cartList")
};